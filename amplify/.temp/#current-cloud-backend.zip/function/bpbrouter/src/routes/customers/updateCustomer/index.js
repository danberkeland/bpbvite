const updateCustomer = async (event) => {
    let response = {}
    return response
  };
  
  export default updateCustomer;